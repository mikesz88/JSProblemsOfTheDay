/*
  Get the average of all numbers in an array in the function
  called 'averageMyNumbers'
  Answer must be a Number and rounded to the nearest hundredths place.
  If parameter is an empty array, return 'Cannot Average'
  If parameter has an array that aren't numbers, return 'Not all are numbers'
  If parameter is not an array, return 'This is not an array of numbers'.
  Example: input: [10,20] output: 15
  */

// Write your code below:
