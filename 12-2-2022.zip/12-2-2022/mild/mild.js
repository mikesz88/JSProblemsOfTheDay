/* 
  Add a property to an object 
  in a function named 'addFavProperty'
  called 'favorite' with a value false.
  Example: input: { mentor: 'Michael'} output: { mentor: 'Michael', favorite: false }
*/

// Write your code below:
